const list = document.getElementById('listacompra');
const input = document.getElementById('item');
const addButton = document.getElementById('addButton');

function agregarArticulo() {
  const itemText = input.value.trim();

  if (itemText === '') return; // Evitar añadir vacíos

  input.value = ''; // Limpiar input
  input.focus();    // Enfocar input

  // Crear elementos
  const li = document.createElement('li');
  const span = document.createElement('span');
  const deleteBtn = document.createElement('button');

  span.textContent = itemText;
  deleteBtn.textContent = 'Eliminar';

  li.appendChild(span);
  li.appendChild(deleteBtn);
  list.appendChild(li);

  // Eliminar el elemento de la lista al hacer clic
  deleteBtn.addEventListener('click', function () {
    list.removeChild(li);
  });
}

// Asociar función al botón
addButton.addEventListener('click', agregarArticulo);

// BONUS: permitir añadir con la tecla Enter
input.addEventListener('keypress', function (e) {
  if (e.key === 'Enter') {
    agregarArticulo();
  }
});
 js